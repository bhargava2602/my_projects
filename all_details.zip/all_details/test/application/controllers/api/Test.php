<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class Test extends REST_Controller {
 	
     public function __construct(){

        parent::__construct();
       // $this->load->database();
        $this->load->model(array("api/Test_model"));
        //$this->load->library(array("form_validation"));
        $this->load->helper("security");
    }

    public function addContact_post()
    {
        $inputJson = file_get_contents('php://input');
        $data = json_decode($inputJson, TRUE);
      
        if($data != '') {
           $first_name = $this->security->xss_clean($data['first_name']);
           $last_name  = $this->security->xss_clean($data['last_name']);
           $mobile     = $this->security->xss_clean($data['mobile']);

            if(!empty($first_name) && !empty($last_name) && !empty($mobile)){
                $contact_details = array(
                      "first_name" => $first_name,
                      "last_name"  => $last_name,
                      "mobile"     => $mobile,
                      "created_datetime" => date('Y-m-d H-i')
                );
                $result = $this->Test_model->insert_contact($contact_details);
                if($result){

                   $this->response(array("status" => 1, "message" => "Contact has been created","contact_id" =>$result), REST_Controller::HTTP_OK);
                }else{

                   $this->response(array("status" => 0,"message" => "Failed to create contact"), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
                }

            }
            else{
                $this->response(array(
                  "status" => 0,
                  "message" => "All fields are needed"
                ), REST_Controller::HTTP_NOT_FOUND);
            }
        }
        else{
            $this->response(array(
                  "status" => 0,
                  "message" => "Enter Proper data"
                ), REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function getContact_get()
    {
        $contct_id = $this->get('id');
        
        if($contct_id != '') {
           
           $id = $this->security->xss_clean($contct_id);

           $contact_details = $this->Test_model->get_contact_details_id($id);

           if(count($contact_details) > 0){
              $this->response(array(
                "status" => 1,
                "message" => "Contact found",
                "data" => $contact_details
              ), REST_Controller::HTTP_OK);
            }else{

              $this->response(array(
                "status" => 0,
                "message" => "No Contact found",
                "data" => $$contact_details
              ), REST_Controller::HTTP_NOT_FOUND);
            }

        }else{
                $this->response(array(
                  "status" => 0,
                  "message" => "Enter Proper data"
                ), REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function searchContact_get()
    {
       $contact_name = $this->get('name');
        
        if($contact_name != '') {
           
           $name = $this->security->xss_clean($contact_name);

           $contact_details = $this->Test_model->get_contact_details_by_name($name);

           if(count($contact_details) > 0){
              $this->response(array(
                "status" => 1,
                "message" => "Contact found",
                "data" => $contact_details
              ), REST_Controller::HTTP_OK);
            }else{

              $this->response(array(
                "status" => 0,
                "message" => "No Contact found",
                "data" => $$contact_details
              ), REST_Controller::HTTP_NOT_FOUND);
            }

        }else{
             $this->response(array(
                  "status" => 0,
                  "message" => "Enter Proper data"
                ), REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function updateContact_post()
    {
        $inputJson = file_get_contents('php://input');
        $data = json_decode($inputJson, TRUE);
      
        if($data != '') {
           $contact_id = $this->security->xss_clean($data['id']);
           $first_name = $this->security->xss_clean($data['first_name']);
           $last_name  = $this->security->xss_clean($data['last_name']);
           $mobile     = $this->security->xss_clean($data['mobile']);

            if(!empty($first_name) && !empty($last_name) && !empty($mobile) && !empty($contact_id)){
                $contact_details = array(
                      "first_name" => $first_name,
                      "last_name"  => $last_name,
                      "mobile"     => $mobile
                );

                $verify_contact_id = $this->Test_model->get_contact_details_id($contact_id);
                 
                
                if(!empty($verify_contact_id)){

                    if($this->Test_model->update_contact_details($contact_id, $contact_details)){

                       $this->response(array("status" => 1, "message" => "Contact Details Updated Successfully"), REST_Controller::HTTP_OK);
                    }else{

                       $this->response(array("status" => 0,"message" => "Failed to update contact details"), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
                    }
                }else{

                     $this->response(array(
                      "status" => 0,
                      "message" => "There is No Contact Id"
                    ), REST_Controller::HTTP_NOT_FOUND);
                }
            }
            else{
                $this->response(array(
                  "status" => 0,
                  "message" => "All fields are needed"
                ), REST_Controller::HTTP_NOT_FOUND);
            }
        }
        else{
            $this->response(array(
                  "status" => 0,
                  "message" => "Enter Proper data"
                ), REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function deleteContact_post()
    {
        $data = json_decode(file_get_contents("php://input"));
        $contact_id = $this->security->xss_clean($data->id);

        if($contact_id != ''){

            $contact_details = $this->Test_model->get_contact_details_id($contact_id);

           if(!empty($contact_details)){

                if($this->Test_model->delete_contact_by_id($contact_id)){
              
                  $this->response(array(
                    "status" => 1,
                    "message" => "Cotnact Deleted Successfully"
                  ), REST_Controller::HTTP_OK);
                }else{
                  // return false
                  $this->response(array(
                    "status" => 0,
                    "message" => "Failed to delete Contact Details"
                  ), REST_Controller::HTTP_NOT_FOUND);
                }
            }else{

                 $this->response(array(
                  "status" => 0,
                  "message" => "There is No Contact to delete"
                ), REST_Controller::HTTP_NOT_FOUND);
            }
             
        }else{

            $this->response(array(
                  "status" => 0,
                  "message" => "Enter Proper data"
                ), REST_Controller::HTTP_NOT_FOUND);
        }
           
    }

    public function listContact_post()
    {
        
        $contacts = $this->Test_model->get_all_contacts();

        if(count($contacts) > 0){
          $this->response(array(
            "status" => 1,
            "message" => "contacts found",
            "data" => $contacts
          ), REST_Controller::HTTP_OK);
        }else{
          $this->response(array(
            "status" => 0,
            "message" => "No contacts found",
            "data" => $contacts
          ), REST_Controller::HTTP_NOT_FOUND);
        }
    
    }
}