<?php

class Test_model extends CI_Model{

  public function __construct(){
    parent::__construct();
    $this->load->database();
  }

  public function insert_contact($data = array()){

       $this->db->insert("contact", $data);
       return $this->db->insert_id();
  }



  public function get_all_contacts(){
    $this->db->select("*");
    $this->db->from("contact");
    $query = $this->db->get();
    return $query->result();
  }

  public function get_contact_details_id($id){

    $this->db->select("*");
    $this->db->from("contact");
    $this->db->where('contact_id',$id);
    $query = $this->db->get();
    return $query->result();
  }

  public function get_contact_details_by_name($name){

    $this->db->select("*");
    $this->db->from("contact");
    $this->db->or_where("`first_name` LIKE '%$name%'");
    $this->db->or_where("`last_name` LIKE '%$name%'");
    $query = $this->db->get();
    return $query->result();
  }

   
   public function delete_contact_by_id($id){
     $this->db->where("contact_id", $id);
     return $this->db->delete("contact");
   }

   public function update_contact_details($id, $updatable_data){
      $this->db->where("contact_id", $id);
      return $this->db->update("contact", $updatable_data);
   }
}

 ?>
